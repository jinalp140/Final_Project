function show()
{
    document.getElementById("bird").style.display="block";
}
function hide()
{
    document.getElementById("bird").style.display="none";
}